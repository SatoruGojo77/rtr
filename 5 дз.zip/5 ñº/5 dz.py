import sqlite3

# Создание базы данных
conn = sqlite3.connect('Blog.db')
c = conn.cursor()

# Создание таблицы Users
c.execute('''CREATE TABLE Users (
                id INTEGER PRIMARY KEY,
                full_name TEXT,
                date_of_birth TEXT,
                role TEXT,
                registration_date TEXT
            )''')

# Создание таблицы Categories
c.execute('''CREATE TABLE Categories (
                id INTEGER PRIMARY KEY,
                name TEXT
            )''')

# Создание таблицы Posts
c.execute('''CREATE TABLE Posts (
                id INTEGER PRIMARY KEY,
                category_id INTEGER,
                user_id INTEGER,
                text TEXT,
                FOREIGN KEY (category_id) REFERENCES Categories(id),
                FOREIGN KEY (user_id) REFERENCES Users(id)
            )''')

# Заполнение таблицы Users
users_data = [
    (1, 'Иванов Иван Иванович', '1990-01-01', 'автор', '2020-01-01'),
    (2, 'Петров Петр Петрович', '1995-02-02', 'читатель', '2020-02-02'),
    (3, 'Сидоров Сидор Сидорович', '1985-03-03', 'автор', '2020-03-03'),
    (4, 'Алексеев Алексей Алексеевич', '1992-04-04', 'читатель', '2020-04-04'),
    (5, 'Николаев Николай Николаевич', '1988-05-05', 'админ', '2020-05-05')
]
c.executemany('INSERT INTO Users VALUES (?, ?, ?, ?, ?)', users_data)

# Заполнение таблицы Categories
categories_data = [
    (1, 'Политика'),
    (2, 'Наука'),
    (3, 'Спорт'),
    (4, 'Искусство'),
    (5, 'Технологии')
]
c.executemany('INSERT INTO Categories VALUES (?, ?)', categories_data)

# Заполнение таблицы Posts
posts_data = [
    (1, 1, 1, 'Пост 1'),
    (2, 2, 2, 'Пост 2'),
    (3, 3, 3, 'Пост 3'),
    (4, 4, 4, 'Пост 4'),
    (5, 5, 5, 'Пост 5')
]
c.executemany('INSERT INTO Posts VALUES (?, ?, ?, ?)', posts_data)

# Сохранение изменений и закрытие соединения
conn.commit()
conn.close()